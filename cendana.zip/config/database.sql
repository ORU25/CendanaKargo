USE cendanalintaskargo;

CREATE TABLE kantor_cabang (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kode_cabang VARCHAR(10) NOT NULL UNIQUE,
    nama_cabang VARCHAR(100) NOT NULL,
    alamat_cabang TEXT NOT NULL,
    telp_cabang VARCHAR(20) NOT NULL
);

CREATE TABLE user (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_cabang INT,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'superAdmin', 'systemOwner') DEFAULT 'admin',
    FOREIGN KEY (id_cabang) REFERENCES kantor_cabang(id) ON DELETE CASCADE
);

CREATE TABLE driver (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_driver VARCHAR(100) NOT NULL,
    telp_driver VARCHAR(20) NOT NULL
);

CREATE TABLE tarif_pengiriman (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_cabang_asal INT NOT NULL,
    id_cabang_tujuan INT NOT NULL,
    tarif_dasar DECIMAL(10,2) NOT NULL,
    batas_berat_dasar INT NOT NULL,
    tarif_tambahan_perkg DECIMAL(10,2) NOT NULL,
    status ENUM('aktif', 'nonaktif') DEFAULT 'aktif',
    FOREIGN KEY (id_cabang_asal) REFERENCES kantor_cabang(id) ON DELETE CASCADE,
    FOREIGN KEY (id_cabang_tujuan) REFERENCES kantor_cabang(id) ON DELETE CASCADE
);

CREATE TABLE pengiriman (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    id_user INT,
    id_cabang_pengirim INT,
    id_cabang_penerima INT,
    id_tarif INT,
    no_resi VARCHAR(50) UNIQUE NOT NULL,
    user VARCHAR(50) NOT NULL,
    cabang_pengirim VARCHAR(100) NOT NULL,
    cabang_penerima VARCHAR(100) NOT NULL,
    nama_pengirim VARCHAR(100) NOT NULL,
    telp_pengirim VARCHAR(20) NOT NULL,
    nama_penerima VARCHAR(100) NOT NULL,
    telp_penerima VARCHAR(20) NOT NULL,
    nama_barang VARCHAR(100) NOT NULL,
    berat DECIMAL(10,2) NOT NULL,
    jumlah INT DEFAULT 1,
    pembayaran ENUM('cash', 'transfer', 'bayar_ditempat', 'invoice') NOT NULL,
    status_pembayaran ENUM('Belum Dibayar', 'Sudah Dibayar') DEFAULT NULL,
    tanggal_pembayaran DATETIME DEFAULT NULL,
    validasi_oleh INT DEFAULT NULL,
    tanggal DATETIME DEFAULT CURRENT_TIMESTAMP,
    diskon DECIMAL(10,2) DEFAULT 0,
    tarif_manual DECIMAL(10,2) DEFAULT 0,
    tarif_handling DECIMAL(10,2) DEFAULT 0,
    tarif_lintas_cabang DECIMAL(10,2) DEFAULT 0,
    total_tarif DECIMAL(10,2) NOT NULL,
    status ENUM('bkd', 'dalam pengiriman', 'sampai tujuan', 'pod', 'dibatalkan') DEFAULT 'bkd',
    FOREIGN KEY (id_user) REFERENCES user(id) ON DELETE SET NULL,
    FOREIGN KEY (id_cabang_pengirim) REFERENCES kantor_cabang(id) ON DELETE SET NULL,
    FOREIGN KEY (id_cabang_penerima) REFERENCES kantor_cabang(id) ON DELETE SET NULL,
    FOREIGN KEY (id_tarif) REFERENCES tarif_pengiriman(id) ON DELETE SET NULL,
    FOREIGN KEY (validasi_oleh) REFERENCES user(id) ON DELETE SET NULL
);

CREATE TABLE surat_jalan (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    id_user INT,
    id_cabang_pengirim INT,
    id_cabang_penerima INT,
    id_driver INT,
    no_surat_jalan VARCHAR(30) UNIQUE NOT NULL,
    user VARCHAR(50) NOT NULL,
    driver VARCHAR(100) NOT NULL,
    cabang_pengirim VARCHAR(100) NOT NULL,
    cabang_penerima VARCHAR(100) NOT NULL,
    tanggal DATETIME DEFAULT CURRENT_TIMESTAMP,
    status ENUM('draft','diberangkatkan') DEFAULT 'draft',
    FOREIGN KEY (id_user) REFERENCES user(id) ON DELETE SET NULL,
    FOREIGN KEY (id_cabang_pengirim) REFERENCES kantor_cabang(id) ON DELETE SET NULL,
    FOREIGN KEY (id_cabang_penerima) REFERENCES kantor_cabang(id) ON DELETE SET NULL,
    FOREIGN KEY (id_driver) REFERENCES driver(id) ON DELETE SET NULL
);

CREATE TABLE detail_surat_jalan (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    id_surat_jalan BIGINT,
    id_pengiriman BIGINT,
    FOREIGN KEY (id_surat_jalan) REFERENCES surat_jalan(id) ON DELETE CASCADE,
    FOREIGN KEY (id_pengiriman) REFERENCES pengiriman(id) ON DELETE CASCADE
);

CREATE TABLE pengambilan (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    id_user INT,
    no_resi VARCHAR(50) NOT NULL,
    nama_pengambil VARCHAR(100) NOT NULL,
    telp_pengambil VARCHAR(20) NOT NULL,
    tanggal DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_user) REFERENCES user(id) ON DELETE CASCADE
);

CREATE TABLE log_status_pengiriman (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    id_pengiriman BIGINT NOT NULL,
    status_lama ENUM('bkd', 'dalam pengiriman', 'sampai tujuan', 'pod', 'dibatalkan'),
    status_baru ENUM('bkd', 'dalam pengiriman', 'sampai tujuan', 'pod', 'dibatalkan') NOT NULL,
    keterangan VARCHAR(255) DEFAULT NULL,
    diubah_oleh INT DEFAULT NULL,
    waktu_perubahan DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_pengiriman) REFERENCES pengiriman(id) ON DELETE CASCADE,
    FOREIGN KEY (diubah_oleh) REFERENCES user(id) ON DELETE SET NULL
);

CREATE TABLE closing (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    id_user INT NOT NULL,
    id_cabang INT NOT NULL,
    tanggal_closing DATE NOT NULL,
    waktu_closing DATETIME DEFAULT CURRENT_TIMESTAMP,
    total_pengiriman INT DEFAULT 0,
    total_cash DECIMAL(10,2) DEFAULT 0,
    total_transfer DECIMAL(10,2) DEFAULT 0,
    total_cod DECIMAL(10,2) DEFAULT 0,
    total_pendapatan DECIMAL(10,2) DEFAULT 0,
    UNIQUE KEY unique_user_date (id_user, tanggal_closing),
    FOREIGN KEY (id_user) REFERENCES user(id) ON DELETE CASCADE,
    FOREIGN KEY (id_cabang) REFERENCES kantor_cabang(id) ON DELETE CASCADE
);

-- akun user systemOwner dengan password 'admin' (hashed)
INSERT INTO user (username, password, role)
VALUES (
    'systemOwner',
    '$2y$10$HsH3nYMyOQtFYkIjtOkQ1O4Ip7IW71cNASjGqY8HQfqXGU5qZTl.u',
    'systemOwner'
);
