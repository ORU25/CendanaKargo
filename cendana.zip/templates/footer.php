    <script src="<?= BASE_URL; ?>Bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>